﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


public class Feedback
{
    public int feedbackId;
    public string isbn;
    public int userId;
    public string date;
    public int rating;
    public string comment;
    public string device;

    public Feedback()
    {
        
    }
}