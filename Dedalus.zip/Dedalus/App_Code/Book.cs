﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


public class Book
{

    public string isbn;
    public string title;
    public string author;
    public string publisher;
    public string publicationYear;
    public string price;
    public string format;
    public string genre;
    public string location;

    public Book()
    {

    }

}