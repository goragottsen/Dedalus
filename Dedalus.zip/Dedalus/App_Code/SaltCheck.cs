﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SaltCheck
/// </summary>
public class SaltCheck
{

    public int saltGrain;
    public Int64 hashValue;
    public string password;
    public string saltedPassword;

    public SaltCheck()
    {
        
    }
}